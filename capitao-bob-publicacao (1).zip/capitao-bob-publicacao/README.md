# Capitão Bob — publicação

Projeto estático pronto para publicação em Vercel.

## Conteúdo
- `index.html` — site completo e responsivo.
- `vercel.json` — configuração mínima para Vercel.
- `robots.txt` — permite rastreamento por motores de busca.

## Publicação
Na Vercel, importe este projeto como um site estático. Não é necessário build command.

## Nota
A publicação torna o site acessível por uma URL pública. A indexação no Google é uma etapa separada e pode exigir o Google Search Console.
